package com.cjkj.mq.rabbit.config;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.mq.rabbit.bean.RabbitMessageQueue;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.LinkedList;
import java.util.List;

/**
 * @description: 绑定队列和交换机
 * @author: RenPL
 * @create: 2019-12-27 10:44
 **/
@Slf4j
@Configuration
public class DefaultRabbitConfig {
    @Bean
    public Jackson2JsonMessageConverter jackson2JsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }
    /**
     * 队列基信息
     */
    @Resource
    private QueuePropertiesConfig queuePropertiesConfig;

    /**
     * 创建队列
     *
     * @param queueName
     * @return
     */
    private Queue createQueue(String queueName) {
        return new Queue(queueName);
    }

    /**
     * 创建主题交换机
     *
     * @param exchangeName
     * @return
     */
    private TopicExchange createTopicExchange(String exchangeName) {
        return new TopicExchange(exchangeName, false, false);
    }

    /**
     * 根据交换机名称查找交换机
     *
     * @param exchanges
     * @param exchangeName
     * @return
     */
    private TopicExchange getTopicExchange(LinkedList<TopicExchange> exchanges, String exchangeName) {
        TopicExchange topicExchange = null;
        for (TopicExchange item : exchanges) {
            if (exchangeName.equals(item.getName())) {
                topicExchange = item;
                break;
            }
        }
        return topicExchange;
    }

    /**
     * 根据队列名称查找队列
     *
     * @param queues
     * @param queueName
     * @return
     */
    private Queue getQueue(LinkedList<Queue> queues, String queueName) {
        Queue queue = null;
        for (Queue item : queues) {
            if (queueName.equals(item.getName())) {
                queue = item;
                break;
            }
        }
        return queue;
    }

    /**
     * 配置交换机
     *
     * @return
     */
    @Bean
    public LinkedList<TopicExchange> builderTopicExchanges() {
        LinkedList<TopicExchange> topicExchanges = new LinkedList<TopicExchange>();
        List<RabbitMessageQueue> messageQueueList = queuePropertiesConfig.getMessageQueues();
        if (!CollectionUtils.isEmpty(messageQueueList)) {
            for (int i = 0; i < messageQueueList.size(); i++) {
                topicExchanges.add(createTopicExchange(messageQueueList.get(i).getExchange()));
                log.info("[ - 正在为{}创建第{}个主题交换机 - ]: {}",messageQueueList.get(i).getBizCode(), i + 1 + "/" + messageQueueList.size(), JSONObject.toJSONString(topicExchanges.get(i)));
            }
        }
        return topicExchanges;
    }

    /**
     * 配置消息队列
     *
     * @return
     */
    @Bean
    public LinkedList<Queue> builderMessageQueues() {
        LinkedList<Queue> messageQueues = new LinkedList<Queue>();
        List<RabbitMessageQueue> messageQueueList = queuePropertiesConfig.getMessageQueues();
        if (!CollectionUtils.isEmpty(messageQueueList)) {
            for (int i = 0; i < messageQueueList.size(); i++) {
                messageQueues.add(createQueue(messageQueueList.get(i).getQueueName()));
                log.info("[ - 正在为{}创建第{}个消息队列 - ]: {}",messageQueueList.get(i).getBizCode(), i + 1 + "/" + messageQueueList.size(), JSONObject.toJSONString(messageQueues.get(i)));
            }
        }
        return messageQueues;
    }

    /**
     * 绑定消息队列到交换机队列
     *
     * @param topicExchanges
     * @param messageQueues
     * @return
     */
    @Bean
    public LinkedList<Binding> buildingExchangeMessage(LinkedList<TopicExchange> topicExchanges, LinkedList<Queue> messageQueues) {
        LinkedList<Binding> bindings = new LinkedList<Binding>();
        List<RabbitMessageQueue> messageQueueList = queuePropertiesConfig.getMessageQueues();
        if (!CollectionUtils.isEmpty(messageQueueList)) {
            Binding binding = null;
            for (int i = 0; i < messageQueueList.size(); i++) {
                binding = BindingBuilder.bind(getQueue(messageQueues, messageQueueList.get(i).getQueueName()))
                        .to(getTopicExchange(topicExchanges, messageQueueList.get(i).getExchange()))
                        .with(messageQueueList.get(i).getRoutingKey());
                bindings.add(binding);
                log.info("[ - 正在为{}绑定第{}个消息队列到交换机队列 - ]: {}",messageQueueList.get(i).getBizCode(), i + 1 + "/" + messageQueueList.size(), JSONObject.toJSONString(binding));
            }
        }
        return bindings;
    }

}
