package com.cjkj.mq.rabbit.bean;

import lombok.Data;

import java.io.Serializable;

/**
 * @description: 消息队列实体
 * @author: RenPL
 * @create: 2019-12-31 10:44
 **/
@Data
public class RabbitMessageQueue implements Serializable {

    private static final long serialVersionUID = 6496629579036573686L;

    /**
     * 业务代码
     */
    private String bizCode;

    /**
     * 交换机
     */
    private String exchange;

    /**
     * 路由key
     */
    private String routingKey;

    /**
     * 队列
     */
    private String queueName;

}
