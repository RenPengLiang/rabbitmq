package com.cjkj.mq.rabbit.sender;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.support.CorrelationData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * @description: 生产者发送
 * @author: Yang.YanFei
 * @create: 2019-12-27 10:57
 **/
@Slf4j
@Component
public class MessageSender implements RabbitTemplate.ConfirmCallback, RabbitTemplate.ReturnCallback {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    /**
     * PostConstruct: 用于在依赖关系注入完成之后需要执行的方法上，以执行任何初始化.
     */
    @PostConstruct
    public void init() {
        //指定 ConfirmCallback
        rabbitTemplate.setConfirmCallback(this);
        //指定 ReturnCallback
        rabbitTemplate.setReturnCallback(this);
    }

    /**
     * 消息从交换机成功到达队列，则returnedMessage方法不会执行;
     * 消息从交换机未能成功到达队列，则returnedMessage方法会执行;
     */
    @Override
    public void returnedMessage(Message message, int replyCode, String replyText, String exchange, String routingKey) {
        log.info("returnedMessage回调方法>>>" + new String(message.getBody(), StandardCharsets.UTF_8) + ",replyCode:" + replyCode
                + ",replyText:" + replyText + ",exchange:" + exchange + ",routingKey:" + routingKey);
    }

    /**
     * 如果消息没有到达交换机,则该方法中isSendSuccess = false,error为错误信息;
     * 如果消息正确到达交换机,则该方法中isSendSuccess = true;
     */
    @Override
    public void confirm(CorrelationData correlationData, boolean isSendSuccess, String error) {
        log.info("confirm回调方法>>>回调消息ID为: " + correlationData.getId());
        if (isSendSuccess) {
            log.info("confirm回调方法>>>消息发送到交换机成功！");
        } else {
            log.info("confirm回调方法>>>消息发送到交换机失败！，原因 : [{}]", error);
        }
    }

    /**
     * 发送消息
     *
     * @param message
     * @param exchangeName
     * @param routingKey
     */
    public void sendRabbit(Object message, String exchangeName, String routingKey, String bizCode) {
        CorrelationData correlationData = new CorrelationData(UUID.randomUUID().toString());
        log.info("【{}】发送的消费ID = {}", bizCode, correlationData.getId());
        log.info("【{}}】发送的消息 = {}", bizCode, message);
        rabbitTemplate.convertAndSend(exchangeName, routingKey, message, correlationData);
    }
}
