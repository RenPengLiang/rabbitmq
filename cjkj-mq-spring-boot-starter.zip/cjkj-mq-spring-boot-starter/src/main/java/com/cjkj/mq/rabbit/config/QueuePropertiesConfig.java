package com.cjkj.mq.rabbit.config;

import com.cjkj.mq.rabbit.bean.RabbitMessageQueue;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * @description: 队列属性配置
 * @author: RenPL
 * @create: 2019-12-27 10:44
 **/
@Setter
@Getter
@Configuration
@ConfigurationProperties(prefix = "queues")
public class QueuePropertiesConfig {
    private List<RabbitMessageQueue> messageQueues;
}
